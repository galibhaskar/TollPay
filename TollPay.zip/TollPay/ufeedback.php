<body>
    <form action="feedsubmit.php" method="POST">
            
        </form>
        </body>